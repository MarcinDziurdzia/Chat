using Microsoft.AspNetCore.Mvc;
using NetworkApplicationProject.Services;
using NetworkProject.Shared.Models;

namespace NetworkApplicationProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IJwtService _jwtService;
        private readonly IUserService _userService;

        public AuthController(IJwtService jwtService, IUserService userService)
        {
            _jwtService = jwtService;
            _userService = userService;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] AuthRequest request)
        {
            if (string.IsNullOrEmpty(request.Username) || string.IsNullOrEmpty(request.Password))
            {
                return BadRequest(new AuthResponse 
                { 
                    Success = false, 
                    Error = "Nazwa użytkownika i hasło są wymagane" 
                });
            }

            if (_userService.Authenticate(request.Username, request.Password))
            {
                var token = _jwtService.GenerateToken(request.Username);
                return Ok(new AuthResponse
                {
                    Success = true,
                    Username = request.Username,
                    Token = token
                });
            }

            return Unauthorized(new AuthResponse 
            { 
                Success = false, 
                Error = "Nieprawidłowa nazwa użytkownika lub hasło" 
            });
        }

        [HttpPost("validate")]
        public IActionResult ValidateToken([FromBody] string token)
        {
            if (string.IsNullOrEmpty(token))
                return BadRequest("Token jest wymagany");

            if (_jwtService.ValidateToken(token, out string username))
            {
                return Ok(new { Valid = true, Username = username });
            }

            return BadRequest(new { Valid = false, Error = "Nieprawidłowy token" });
        }
    }
}
