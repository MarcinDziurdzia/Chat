using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using NetworkApplicationProject.Hubs;
using NetworkProject.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NetworkApplicationProject.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class MessagesController : ControllerBase
    {
        private readonly IHubContext<ChatHub> _hubContext;
        private static readonly List<Message> _messageHistory = new List<Message>();

        public MessagesController(IHubContext<ChatHub> hubContext)
        {
            _hubContext = hubContext;
        }

        [HttpGet]
        public IActionResult GetMessages()
        {
            // W rzeczywistej aplikacji, pobieralibyśmy to z bazy danych
            return Ok(_messageHistory.OrderByDescending(m => m.Timestamp).Take(50).OrderBy(m => m.Timestamp));
        }

        [HttpPost]
        public IActionResult SendMessage([FromBody] Message message)
        {
            if (string.IsNullOrEmpty(message.Content))
                return BadRequest("Treść wiadomości jest wymagana");

            // Uzupełniamy dane wiadomości
            message.Sender = User.Identity.Name;
            message.Timestamp = DateTime.Now;
            message.Id = _messageHistory.Count > 0 ? _messageHistory.Max(m => m.Id) + 1 : 1;

            // Dodajemy do historii
            _messageHistory.Add(message);

            // Rozsyłamy wiadomość przez SignalR
            _hubContext.Clients.All.SendAsync("ReceiveMessage", message);

            return Ok(message);
        }
    }
}
