﻿using Microsoft.AspNetCore.Mvc;

namespace NetworkProject.Server.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}