using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using NetworkApplicationProject.Services;
using NetworkProject.Shared.Models;
using System;
using System.Threading.Tasks;

namespace NetworkApplicationProject.Hubs
{
    [Authorize]
    public class ChatHub : Hub
    {
        private readonly IUserService _userService;

        public ChatHub(IUserService userService)
        {
            _userService = userService;
        }

        public override async Task OnConnectedAsync()
        {
            var username = Context.User.Identity.Name;
            
            // Dodajemy lub aktualizujemy użytkownika
            var existingUser = _userService.GetUserByUsername(username);
            if (existingUser != null)
            {
                _userService.UpdateConnectionId(username, Context.ConnectionId);
            }
            else
            {
                _userService.AddUser(username, Context.ConnectionId);
            }

            // Powiadom wszystkich o nowym połączeniu
            await Clients.All.SendAsync("UserConnected", username);
            
            // Wyślij listę aktywnych użytkowników do nowo połączonego klienta
            await Clients.Caller.SendAsync("GetOnlineUsers", _userService.GetAllUsers());
            
            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            var user = _userService.GetUserByConnectionId(Context.ConnectionId);
            if (user != null)
            {
                user.IsOnline = false;
                user.LastSeen = DateTime.Now;
                
                // Powiadom wszystkich o rozłączeniu
                await Clients.All.SendAsync("UserDisconnected", user.Username);
            }

            await base.OnDisconnectedAsync(exception);
        }

        public async Task SendMessage(string content)
        {
            var user = _userService.GetUserByConnectionId(Context.ConnectionId);
            if (user != null)
            {
                var message = new Message
                {
                    Content = content,
                    Sender = user.Username,
                    Timestamp = DateTime.Now
                };

                // Wysyłamy wiadomość do wszystkich
                await Clients.All.SendAsync("ReceiveMessage", message);
            }
        }

        public async Task SendPrivateMessage(string recipientUsername, string content)
        {
            var sender = _userService.GetUserByConnectionId(Context.ConnectionId);
            var recipient = _userService.GetUserByUsername(recipientUsername);

            if (sender != null && recipient != null)
            {
                var message = new Message
                {
                    Content = content,
                    Sender = sender.Username,
                    Timestamp = DateTime.Now
                };

                // Wysyłamy do odbiorcy
                await Clients.Client(recipient.ConnectionId).SendAsync("ReceivePrivateMessage", message);
                
                // Wysyłamy też do nadawcy potwierdzenie
                await Clients.Caller.SendAsync("ReceivePrivateMessage", message);
            }
        }
    }
}
