using NetworkProject.Shared.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace NetworkApplicationProject.Services
{
    public interface IUserService
    {
        bool Authenticate(string username, string password);
        bool AddUser(string username, string connectionId);
        bool RemoveUser(string connectionId);
        User GetUserByConnectionId(string connectionId);
        User GetUserByUsername(string username);
        IEnumerable<User> GetAllUsers();
        void UpdateConnectionId(string username, string connectionId);
    }

    public class UserService : IUserService
    {
        // W prawdziwej aplikacji używalibyśmy bazy danych
        // Dla uproszczenia używamy słownika
        private readonly ConcurrentDictionary<string, User> _users = new ConcurrentDictionary<string, User>();
        
        // Tymczasowa prosta "baza" użytkowników z hasłami (w rzeczywistym projekcie używaj haszowanych haseł w bazie danych!)
        private readonly Dictionary<string, string> _credentials = new Dictionary<string, string>
        {
            { "user1", "password1" },
            { "user2", "password2" }
        };

        public bool Authenticate(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                return false;

            return _credentials.TryGetValue(username, out string storedPassword) && storedPassword == password;
        }

        public bool AddUser(string username, string connectionId)
        {
            var user = new User
            {
                Username = username,
                ConnectionId = connectionId,
                IsOnline = true,
                LastSeen = DateTime.Now
            };

            return _users.TryAdd(connectionId, user);
        }

        public bool RemoveUser(string connectionId)
        {
            return _users.TryRemove(connectionId, out _);
        }

        public User GetUserByConnectionId(string connectionId)
        {
            _users.TryGetValue(connectionId, out User user);
            return user;
        }

        public User GetUserByUsername(string username)
        {
            return _users.Values.FirstOrDefault(u => u.Username == username);
        }

        public IEnumerable<User> GetAllUsers()
        {
            return _users.Values;
        }

        public void UpdateConnectionId(string username, string connectionId)
        {
            var user = GetUserByUsername(username);
            if (user != null)
            {
                // Usuń stare mapowanie
                _users.TryRemove(user.ConnectionId, out _);
                
                // Zaktualizuj i dodaj nowe
                user.ConnectionId = connectionId;
                user.IsOnline = true;
                user.LastSeen = DateTime.Now;
                _users.TryAdd(connectionId, user);
            }
        }
    }
}
