// Message.cs
using System;

namespace NetworkProject.Shared.Models
{
    public class Message
    {
        public int Id { get; set; }
        public string Content { get; set; }
        public string Sender { get; set; }
        public DateTime Timestamp { get; set; }
    }
}

// User.cs
using System;

namespace NetworkProject.Shared.Models
{
    public class User
    {
        public string Username { get; set; }
        public string ConnectionId { get; set; }
        public bool IsOnline { get; set; }
        public DateTime LastSeen { get; set; }
    }
}

// AuthRequest.cs
namespace NetworkProject.Shared.Models
{
    public class AuthRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}

// AuthResponse.cs
namespace NetworkProject.Shared.Models
{
    public class AuthResponse
    {
        public string Token { get; set; }
        public string Username { get; set; }
        public bool Success { get; set; }
        public string Error { get; set; }
    }
}
